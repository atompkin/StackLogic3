package translator;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class VMTranslator 
{
	int mySP = 0;
	public static void main(String args[])
	{
		try{
			Scanner in = new Scanner(new FileReader(args[0]));
			while(in.hasNext())
			{
				String line = in.nextLine();
				translator(line);
			}
		} catch (FileNotFoundException e){
			e.printStackTrace();
		}
	}
	
	public static void translator(String line)
	{
		if(line.contains("add"))
		{
			add();
		}
		
		if(line.contains("sub"))
		{
			subtract();
		}
		if(line.contains("not"))
		{
			not();
		}
		if(line.contains("neg"))
		{
			neg();
		}
		if(line.contains("or"))
		{
			or();
		}
		if(line.contains("and"))
		{
			and();
		}
		if(line.contains("lt"))
		{
			lt();
		}
		if(line.contains("gt"))
		{
			gt();
		}
		if(line.contains("eq"))
		{
			eq();
		}
		if(line.contains("if-goto"))
		{
			String s = line.substring(line.indexOf("goto ")+1);
			ifGoto(s);
		}
		else if(line.contains("goto"))
		{
			String s = line.substring(line.indexOf("goto ")+1);
			goTo(s);
		}
		if(line.contains("label"));
		{
			String s = line.substring(line.indexOf("label ") + 1);
			label(s);
		}
		
		if(line.contains("push"))
		{
			if(line.contains("constant"))
			{
				String s = line.substring(line.indexOf("constant ") + 1);
				pushConstant(s);
			}
			if(line.contains("local"))
			{
				String s = line.substring(line.indexOf("local ") + 1);
				pushLocal(s);
			}
			if(line.contains("argument"))
			{
				String s = line.substring(line.indexOf("argument ") + 1);
				pushArgument(s);
			}
			if(line.contains("temp"))
			{
				String s = line.substring(line.indexOf("temp ") + 1);
				pushTemp(s);
			}
			if(line.contains("call"))
			{
				String s = line.substring(line.indexOf("call ") + 1);
				call(s);
			}
			if(line.contains("function"))
			{
				String s = line.substring(line.indexOf("function ") + 1);
				 function(s);
			}
		}
		
		if(line.contains("pop"))
		{
			if(line.contains("local"))
			{
				popLocal();
			}
			if(line.contains("argument"))
			{
				popArgument();
			}
			if(line.contains("temp"))
			{
				popTemp();
			}
		}
	}
	
	public static void add()
	{
		// pop top of the stack
		System.out.println("@SP");
		System.out.println("M=M-1");
		System.out.println("A=M");
		System.out.println("D=M");
		System.out.println("A=M-1");
		System.out.println("M=M+D");
	}
	
	public static void subtract()
	{
		System.out.println("@SP");
		System.out.println("M=M-1");
		System.out.println("A=M");
		System.out.println("D=M");
		System.out.println("A=M-1");
		System.out.println("M=M-D");
	}
	
	public static void neg()
	{
		System.out.println("@SP");
		System.out.println("M=M-1");
		System.out.println("A=M");
		System.out.println("M=-M");
		System.out.println("D=A+1");
		System.out.println("@SP");
		System.out.println("M=D");
	}
	
	public static void and()
	{
		System.out.println("@SP");
		System.out.println("M=M-1");
		System.out.println("A=M");
		System.out.println("D=M");
		System.out.println("@SP");
		System.out.println("A=A-1");
		System.out.println("D=D&M");
		System.out.println("M=D");
	}
	
	public static void or()
	{
		System.out.println("@SP");
		System.out.println("M=M-1");
		System.out.println("A=M");
		System.out.println("D=M");
		System.out.println("@SP");
		System.out.println("A=A-1");
		System.out.println("D=D|M");
		System.out.println("M=D");
		System.out.println("D=A+1");
		System.out.println("@SP");
		System.out.println("M=D");
	}
	
	public static void not()
	{
		System.out.println("@SP");
		System.out.println("A=M-1");
		System.out.println("M=!M");
	}
	
	public static void lt()
	{
		System.out.println("@SP");
		System.out.println("M=M-1");
		System.out.println("A=M");
		System.out.println("D=M");
		System.out.println("@SP");
		System.out.println("M=M-1");
		System.out.println("A=M");
		System.out.println("D=M-D");
		System.out.println("D;JLT");
		
	}
	
	public static void gt()
	{
		System.out.println("@SP");
		System.out.println("M=M-1");
		System.out.println("A=M");
		System.out.println("D=M");
		System.out.println("@SP");
		System.out.println("M=M-1");
		System.out.println("A=M");
		System.out.println("D=M-D");
		System.out.println("D;GLT");
	}
	
	public static void eq()
	{
		System.out.println("@SP");
		System.out.println("M=M-1");
		System.out.println("A=M");
		System.out.println("D=M");
		System.out.println("@SP");
		System.out.println("M=M-1");
		System.out.println("A=M");
		System.out.println("D=M-D");
		System.out.println("D;JEQ");
	}
	
	public static void label(String label)
	{
		
		System.out.println("("+label+")");
	}
	
	public static void ifGoto(String label)
	{
		System.out.println("@SP");
		System.out.println("M=M-1");
		System.out.println("A=M");
		System.out.println("D=M");
		System.out.println("@" +label);
		System.out.println("D;JLT");
		
	}

	public static void goTo(String label)
	{
		System.out.println("@" + label);
		System.out.println("0;JMP");
	}
	
	public static void popStatic()
	{
		System.out.println("@SP");
		System.out.println("A=M-1");
		System.out.println("D=M");
		System.out.println("@SP");
		System.out.println("M=M+D");
	}
	
	public static void popLocal()
	{
		System.out.println("@SP");
		System.out.println("D=A");
		System.out.println("@LCL");
		System.out.println("D=M+D");
		System.out.println("@R14");
		System.out.println("M=D");
		System.out.println("@SP");
		System.out.println("D=M");
		System.out.println("@R14");
		System.out.println("A=M");
		System.out.println("M=D");
		System.out.println("@SP");
		System.out.println("M=M-1");
		
	}
	
	public static void popArgument()
	{
		System.out.println("@SP");
		System.out.println("D=A");
		System.out.println("@ARG");
		System.out.println("D=M+D");
		System.out.println("@R14");
		System.out.println("M=D");
		System.out.println("@SP");
		System.out.println("D=M");
		System.out.println("@R14");
		System.out.println("A=M");
		System.out.println("M=D");
		System.out.println("@SP");
		System.out.println("M=M-1");
		
	}
	
	public static void popTemp()
	{
		System.out.println("A=M-1");
		System.out.println("D=M");
		System.out.println("@SP");
		System.out.println("M=M+D");
	}
	public static void pushConstant(String s)
	{
		System.out.println("@" + s);
		System.out.println("D=A");
		System.out.println("@SP");
		System.out.println("A=M");
		System.out.println("M=D");
		System.out.println("@SP");
		System.out.println("M=M+1");
	}
	
	public static void pushStatic(String s)
	{
		System.out.println("A=" +s+16);
		System.out.println("D=M");
		System.out.println("@SP");
		System.out.println("A=M");
		System.out.println("M=D");
		System.out.println("@SP");
		System.out.println("M=M+1");
	}
	
	public static void pushLocal(String s)
	{
		System.out.println("@LCL");
		System.out.println("D=M");
		System.out.println("@R5");
		System.out.println("D=D+R5");
		System.out.println("A=D");
		System.out.println("D=M");
		System.out.println("@SP");
		System.out.println("A=D");
		System.out.println("M=D");
		System.out.println("@SP");
		System.out.println("M=M+1");
		
		}
	
	public static void pushArgument(String s)
	{
		System.out.println("@ARG");
		System.out.println("D=M");
		System.out.println("@R5");
		System.out.println("D=D+R5");
		System.out.println("A=D");
		System.out.println("D=M");
		System.out.println("@SP");
		System.out.println("A=D");
		System.out.println("M=D");
		System.out.println("@SP");
		System.out.println("M=M+1");
	}
	
	public static void pushTemp(String s)
	{
		System.out.println("A=" +s+5);
		System.out.println("D=M");
		System.out.println("@SP");
		System.out.println("A=M");
		System.out.println("M=D");
		System.out.println("@SP");
		System.out.println("M=M+1");
	}
	
	public static void function(String name)
	{
		label(name);
		System.out.println("A=" + Integer.parseInt(name.replaceAll("[\\D]", "")));
		System.out.println("D=A");
		System.out.println("@ARG");
		System.out.println("M=D");
		
		
	}
	
	public static void call(String function)
	{
		System.out.println("@" + function);
		System.out.println("D=A");
		System.out.println("@SP");
		System.out.println("M=D");
		System.out.println("D=M");
		System.out.println("(" + function + ")");
		System.out.println("0;JMP");
	}
	
	public static void returnAns()
	{
		System.out.println("@SP");
		System.out.println("D=M");
		System.out.println("M=A-1");
		System.out.println("@R13");
		System.out.println("M=D");
		System.out.println("@ARG");
		System.out.println("D=M");
		System.out.println("@R14");
		System.out.println("M=D");
		System.out.println("");
	}
}
